/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 90.84745762711864, "KoPercent": 9.152542372881356};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.337, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/upcomingholidaysandleaves"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002078"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/leavedetailsinfo"], "isController": false}, {"data": [0.775, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/recentsearch"], "isController": false}, {"data": [0.08, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/notificationservice\/NotificationStatus\/GetNotificationsCount"], "isController": false}, {"data": [0.02, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/recenthiresemployees"], "isController": false}, {"data": [0.2, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/policy\/getattendancelist"], "isController": false}, {"data": [0.98, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000002347"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000001973"], "isController": false}, {"data": [0.0, 500, 1500, "Test"], "isController": true}, {"data": [0.84, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/officetypecommondata\/getstateswithcities"], "isController": false}, {"data": [0.16, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getactiveemployees"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/policy\/getassignedpolicybyemployeecode\/100000001915"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/alldevicestatus"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leavetype\/getallleavetypes"], "isController": false}, {"data": [0.98, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/weeklyoffpolicy\/getallweeklyoffpolicies"], "isController": false}, {"data": [0.04, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/device\/getdevice"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/auditlog-microservice.azurewebsites.net\/api\/v1\/auditlogservice\/userconfig\/getconfig\/Dashboard"], "isController": false}, {"data": [0.86, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000001973"], "isController": false}, {"data": [0.76, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000002347"], "isController": false}, {"data": [0.02, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/account\/login"], "isController": false}, {"data": [0.04, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployees"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000002078"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeeonboardingoffboardinggraphstatistics"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000001915"], "isController": false}, {"data": [0.04, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/myattendance"], "isController": false}, {"data": [0.2, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000002347"], "isController": false}, {"data": [0.22, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000001973"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/upcommingcelebration"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/companylogo\/namco"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/clockindetails\/getlastclockindetails"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/documentservice\/myfiles\/getfiles"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeestrength"], "isController": false}, {"data": [0.84, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000002078"], "isController": false}, {"data": [0.86, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/generalsetting\/get"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000002347"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000001973"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002347"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000001973"], "isController": false}, {"data": [0.04, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/company\/checkcompanyinfo"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/tenant\/tenantcode"], "isController": false}, {"data": [0.82, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leavepolicy\/getallleavepolicies"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/getreporteespendingrequests"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/searchservice\/GlobalSearch"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getrolewisecount"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/yesterdayattendancesummary"], "isController": false}, {"data": [0.24, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000002078"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/todayattendancesummary"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/pendingrequest"], "isController": false}, {"data": [1.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000002078"], "isController": false}, {"data": [0.88, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leaveimport\/getbannerstatus"], "isController": false}, {"data": [0.0, 500, 1500, "https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeesoffboardingcount"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1475, 135, 9.152542372881356, 28112.581016949207, 15, 240097, 100267.2, 118599.60000000002, 213037.28, 0.8757388861313834, 11.132890309956647, 0.0], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/upcomingholidaysandleaves", 25, 6, 24.0, 97814.12000000001, 26708, 165567, 145923.2, 160324.19999999998, 165567.0, 0.058891289036090935, 0.04093174632106117, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002078", 25, 25, 100.0, 24.999999999999996, 15, 103, 45.000000000000085, 92.79999999999998, 103.0, 0.4196531985966797, 0.10081512388162422, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/leavedetailsinfo", 25, 25, 100.0, 216769.91999999998, 176785, 240097, 240090.8, 240096.4, 240097.0, 0.041408073249225255, 0.0145235581915935, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/recentsearch", 100, 1, 1.0, 800.4099999999997, 29, 6349, 3171.0000000000005, 4436.749999999999, 6347.65, 0.06069843258437537, 0.06500896971087515, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/notificationservice\/NotificationStatus\/GetNotificationsCount", 25, 0, 0.0, 4357.96, 218, 9906, 8062.400000000004, 9723.0, 9906.0, 0.32544032075398016, 0.10996323337976281, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/recenthiresemployees", 25, 0, 0.0, 16408.48, 1368, 159976, 64105.0000000003, 156205.9, 159976.0, 0.10206164523372117, 0.032890959889773426, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/policy\/getattendancelist", 25, 0, 0.0, 4220.84, 182, 6056, 6005.8, 6044.9, 6056.0, 2.172590597027896, 2.174712267532806, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000002347", 25, 0, 0.0, 129.6, 33, 519, 322.0000000000002, 477.8999999999999, 519.0, 0.29847895126435686, 0.33494934812197047, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000001973", 25, 0, 0.0, 91.6, 35, 177, 144.60000000000002, 167.99999999999997, 177.0, 0.3887783030604628, 0.42768650667143565, 0.0], "isController": false}, {"data": ["Test", 25, 25, 100.0, 1658642.2799999998, 1627295, 1683487, 1678581.8, 1682459.5, 1683487.0, 0.01484198334017054, 11.132103795295507, 0.0], "isController": true}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/officetypecommondata\/getstateswithcities", 25, 0, 0.0, 452.47999999999996, 120, 1584, 1210.0000000000002, 1488.8999999999999, 1584.0, 0.342156406536556, 13.393218010942162, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getactiveemployees", 25, 0, 0.0, 3867.2400000000002, 1010, 11690, 9574.400000000007, 11627.9, 11690.0, 0.2956235883973654, 75.2486171282829, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/policy\/getassignedpolicybyemployeecode\/100000001915", 25, 0, 0.0, 15112.840000000002, 3487, 27169, 23564.600000000006, 26509.6, 27169.0, 0.13918891833507785, 0.2687270425277821, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/alldevicestatus", 25, 0, 0.0, 35128.68, 13585, 52633, 51636.2, 52339.9, 52633.0, 0.09082520145029682, 0.032462913799617805, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leavetype\/getallleavetypes", 25, 0, 0.0, 245.12, 136, 434, 426.40000000000003, 433.7, 434.0, 0.4391897826888955, 0.7222613223125977, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/weeklyoffpolicy\/getallweeklyoffpolicies", 25, 0, 0.0, 260.2399999999999, 142, 520, 421.0000000000001, 501.99999999999994, 520.0, 0.4410182228729691, 0.4763341352514686, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/device\/getdevice", 25, 0, 0.0, 3129.76, 527, 7326, 6528.400000000001, 7122.0, 7326.0, 1.8196375282043817, 4.757001624026493, 0.0], "isController": false}, {"data": ["https:\/\/auditlog-microservice.azurewebsites.net\/api\/v1\/auditlogservice\/userconfig\/getconfig\/Dashboard", 25, 0, 0.0, 5823.5999999999985, 1859, 17433, 8797.400000000001, 14938.799999999994, 17433.0, 0.12909888974954814, 0.2442036615672605, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000001973", 25, 0, 0.0, 450.4800000000001, 161, 1406, 1055.200000000001, 1381.3999999999999, 1406.0, 0.39730468501684574, 0.12881362834530544, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000002347", 25, 0, 0.0, 565.52, 185, 2009, 1367.6000000000022, 2004.5, 2009.0, 0.37174721189591076, 0.12052741635687732, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/account\/login", 25, 0, 0.0, 9148.840000000002, 1492, 20583, 15693.200000000004, 19474.799999999996, 20583.0, 0.37639265281541706, 0.8399290264604035, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployees", 25, 0, 0.0, 2915.04, 1418, 7699, 4862.000000000004, 7136.799999999998, 7699.0, 0.36525143909067, 107.33398637246881, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getuserbyemployeecode\/100000002078", 25, 0, 0.0, 66.59999999999998, 31, 181, 136.60000000000002, 168.39999999999998, 181.0, 0.4006217649792478, 0.44570736282710766, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeeonboardingoffboardinggraphstatistics", 25, 0, 0.0, 38827.96000000001, 18242, 99085, 63422.60000000001, 89375.19999999998, 99085.0, 0.06356228468276064, 0.03581585767768837, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000001915", 25, 0, 0.0, 58855.560000000005, 8812, 85839, 74340.20000000001, 83072.09999999999, 85839.0, 0.1550339524355834, 0.7992424169018015, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/myattendance", 25, 0, 0.0, 7684.199999999997, 359, 58545, 25738.600000000108, 57910.799999999996, 58545.0, 0.28393925971356204, 0.3241455025440958, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000002347", 25, 0, 0.0, 2656.48, 892, 6315, 6247.8, 6306.0, 6315.0, 0.34124102536103296, 0.5655136914430401, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000001973", 25, 0, 0.0, 2203.08, 961, 6437, 5029.0, 6041.599999999999, 6437.0, 0.3835532371893219, 0.614659045144216, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/upcommingcelebration", 25, 3, 12.0, 83795.2, 6498, 183350, 180194.2, 182512.7, 183350.0, 0.05920018186295868, 0.1430077518198136, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/companylogo\/namco", 25, 0, 0.0, 5897.68, 1783, 16108, 12696.200000000012, 16022.8, 16108.0, 0.1328451716093927, 0.048000696772925094, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/clockindetails\/getlastclockindetails", 25, 0, 0.0, 63082.72, 32703, 90406, 80491.8, 87776.79999999999, 90406.0, 0.09161301197931744, 0.02970265622766933, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/documentservice\/myfiles\/getfiles", 25, 0, 0.0, 61634.20000000001, 12914, 174278, 113175.40000000005, 160474.39999999997, 174278.0, 0.13879712856500426, 0.10491111084893875, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeestrength", 25, 0, 0.0, 53724.8, 36315, 72316, 63522.8, 69681.09999999999, 72316.0, 0.08536006582968277, 0.03301033795757263, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/employeeface\/getemployeeface\/100000002078", 25, 0, 0.0, 436.36, 170, 929, 839.4000000000002, 918.5, 929.0, 0.41546182736730153, 0.1347005143417423, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/generalsetting\/get", 25, 0, 0.0, 495.96, 88, 2464, 1796.4000000000024, 2459.2, 2464.0, 0.4188867665292718, 0.24380518833149023, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000002347", 25, 0, 0.0, 98.56000000000002, 35, 337, 225.4, 304.5999999999999, 337.0, 0.299007295778017, 0.17550326665470636, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000001973", 25, 0, 0.0, 61.760000000000005, 34, 137, 99.00000000000006, 130.1, 137.0, 0.38931713774040333, 0.22863257221832903, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002347", 25, 25, 100.0, 34.4, 15, 122, 101.0, 115.69999999999999, 122.0, 0.37472270519815337, 0.09002127488158763, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000001973", 25, 25, 100.0, 18.76, 15, 29, 21.0, 26.599999999999994, 29.0, 0.4007052412245552, 0.09626317318480526, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/companyservice\/company\/checkcompanyinfo", 25, 0, 0.0, 7596.28, 552, 14795, 13918.400000000003, 14784.2, 14795.0, 0.33533640948599636, 0.12837096925635796, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/tenant\/tenantcode", 25, 0, 0.0, 167.00000000000003, 85, 353, 287.4, 333.49999999999994, 353.0, 0.43877354020043174, 0.17953722006248135, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leavepolicy\/getallleavepolicies", 25, 0, 0.0, 414.91999999999996, 172, 1938, 617.0, 1546.199999999999, 1938.0, 0.43550972057696324, 0.9016412183819942, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/getreporteespendingrequests", 25, 0, 0.0, 53808.68, 41689, 75655, 68749.00000000001, 74575.0, 75655.0, 0.07976975258613538, 0.029446256325741382, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/searchservice\/GlobalSearch", 150, 0, 0.0, 78114.05999999998, 9323, 100674, 100504.3, 100560.25, 100660.74, 0.2686963391019452, 5.115318800929153, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/getrolewisecount", 25, 0, 0.0, 87.64, 31, 435, 197.40000000000015, 375.59999999999985, 435.0, 0.2999508080674769, 0.21774553973148406, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/yesterdayattendancesummary", 25, 25, 100.0, 52969.520000000004, 27167, 122527, 116703.6, 120825.7, 122527.0, 0.0753186733067609, 0.03295191957170789, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employee\/getemployeeprofilelist\/100000002078", 25, 0, 0.0, 2493.64, 919, 6326, 5989.6, 6294.2, 6326.0, 0.3948324331153858, 0.7241165130768502, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/todayattendancesummary", 25, 0, 0.0, 135397.08000000002, 51608, 180817, 170348.80000000002, 178516.6, 180817.0, 0.06821580205411423, 0.028080395392431866, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/pendingrequest", 25, 0, 0.0, 104722.92, 79513, 121848, 119436.8, 121143.9, 121848.0, 0.07303833636198968, 0.026533458131504064, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/user\/GetTotalInvitationSentMail\/100000002078", 25, 0, 0.0, 69.44, 33, 143, 130.60000000000002, 141.8, 143.0, 0.4011746393439993, 0.23554906265545517, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/leaveimport\/getbannerstatus", 25, 0, 0.0, 356.32, 81, 1976, 1947.6000000000001, 1970.0, 1976.0, 0.4391820673178273, 0.1788466035854824, 0.0], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/employeesoffboardingcount", 25, 0, 0.0, 32181.199999999997, 21708, 45408, 42151.0, 44557.799999999996, 45408.0, 0.08726216696393978, 0.03314939741110603, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["504\/Gateway Timeout", 5, 3.7037037037037037, 0.3389830508474576], "isController": false}, {"data": ["499", 1, 0.7407407407407407, 0.06779661016949153], "isController": false}, {"data": ["500\/Internal Server Error", 50, 37.03703703703704, 3.389830508474576], "isController": false}, {"data": ["404\/Resource Not Found", 75, 55.55555555555556, 5.084745762711864], "isController": false}, {"data": ["401\/Unauthorized", 4, 2.962962962962963, 0.2711864406779661], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1475, 135, "404\/Resource Not Found", 75, "500\/Internal Server Error", 50, "504\/Gateway Timeout", 5, "401\/Unauthorized", 4, "499", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/upcomingholidaysandleaves", 25, 6, "500\/Internal Server Error", 5, "401\/Unauthorized", 1, null, null, null, null, null, null], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002078", 25, 25, "404\/Resource Not Found", 25, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/leaveservice\/dashboard\/leavedetailsinfo", 25, 25, "500\/Internal Server Error", 19, "504\/Gateway Timeout", 5, "499", 1, null, null, null, null], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/userservice\/recentsearch", 100, 1, "500\/Internal Server Error", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/dashboard\/upcommingcelebration", 25, 3, "401\/Unauthorized", 3, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000002347", 25, 25, "404\/Resource Not Found", 25, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/employeeservice\/employeeprofileview\/getsection\/100000001973", 25, 25, "404\/Resource Not Found", 25, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["https:\/\/dev-app.mewurk.com\/api\/v1\/attendanceservice\/dashboard\/yesterdayattendancesummary", 25, 25, "500\/Internal Server Error", 25, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
